﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Controller
{
    class DutyController
    {
        private readonly Context _context;
        public DutyController(Context context)
        {
            _context = context;
        }
    }
}
